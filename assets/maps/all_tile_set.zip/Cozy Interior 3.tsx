<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Cozy Interior 3" tilewidth="16" tileheight="16" tilecount="24" columns="8">
 <image source="../images/tileset/Cozy Interior 3.png" width="128" height="48"/>
</tileset>