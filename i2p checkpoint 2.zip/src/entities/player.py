from __future__ import annotations
import pygame as pg
from .entity import Entity
from src.core.services import input_manager, scene_manager
from src.utils import Position, PositionCamera, GameSettings, Logger
from src.core import GameManager
import math
from typing import override
import random

class Player(Entity):
    speed: float = 4.0 * GameSettings.TILE_SIZE
    game_manager: GameManager
    bush_encounter_cooldown: float  # Cooldown timer to prevent instant re-encounters

    def __init__(self, x: float, y: float, game_manager: GameManager) -> None:
        super().__init__(x, y, game_manager)
        self.bush_encounter_cooldown = 0.0  # Start with no cooldown

    def _check_bush_encounter(self) -> bool:
        """Check if player is in a bush and trigger encounter."""
        # If cooldown is active, no encounter
        if self.bush_encounter_cooldown > 0:
            return False
            
        player_rect = self.animation.rect
        for bush_rect in self.game_manager.current_map._bush_map:
            if player_rect.colliderect(bush_rect):
                # 100% encounter rate for debugging (change to 0.001 for normal gameplay)
                if random.random() < 1.0:
                    # Set cooldown to 3 seconds after triggering encounter
                    self.bush_encounter_cooldown = 3.0
                    return True
        return False

    @override
    def update(self, dt: float) -> None:
        # Update cooldown timer
        if self.bush_encounter_cooldown > 0:
            self.bush_encounter_cooldown -= dt
        
        dis = Position(0, 0)
        
        if input_manager.key_down(pg.K_LEFT) or input_manager.key_down(pg.K_a):
            self.direction = "left"
            dis.x -= 1
        
        if input_manager.key_down(pg.K_RIGHT) or input_manager.key_down(pg.K_d):
            self.direction = "right"
            dis.x += 1

        if input_manager.key_down(pg.K_UP) or input_manager.key_down(pg.K_w):
            self.direction = "up"
            dis.y -= 1

        if input_manager.key_down(pg.K_DOWN) or input_manager.key_down(pg.K_s):
            self.direction = "down"
            dis.y += 1

        hyp = math.hypot(dis.x, dis.y)
        if hyp:
            dis.x /= hyp
            dis.y /= hyp

        to_check_x = self.animation.rect.copy()
        to_check_x.x += int(dis.x * self.speed * dt)
        if self.game_manager.check_collision(to_check_x):
            self.position.x = self._snap_to_grid(self.position.x)
        else:
            self.position.x += dis.x * self.speed * dt
        
        to_check_y = self.animation.rect.copy()
        to_check_y.y += int(dis.y * self.speed * dt)
        if self.game_manager.check_collision(to_check_y):    
            self.position.y = self._snap_to_grid(self.position.y)
        else:
            self.position.y += dis.y * self.speed * dt
        
        # Check for bush encounter BEFORE teleportation
        if self._check_bush_encounter():
            scene_manager.change_scene("wild_pokemon", self.game_manager)
            return  # Exit early so we don't check teleportation
        
        # Check teleportation
        tp = self.game_manager.current_map.check_teleport(self.position)
        if tp:
            dest = tp.destination
            self.game_manager.switch_map(dest)

        if self.direction == "left":
            self.animation.switch("left")

        elif self.direction == "right":
            self.animation.switch("right")

        elif self.direction == "up":
            self.animation.switch("up")

        elif self.direction == "down":
            self.animation.switch("down")
                
        super().update(dt)
    
    @override
    def draw(self, screen: pg.Surface, camera: PositionCamera) -> None:
        super().draw(screen, camera)
        
    @override
    def to_dict(self) -> dict[str, object]:
        return super().to_dict()
    
    @classmethod
    @override
    def from_dict(cls, data: dict[str, object], game_manager: GameManager) -> Player:
        return cls(data["x"] * GameSettings.TILE_SIZE, data["y"] * GameSettings.TILE_SIZE, game_manager)