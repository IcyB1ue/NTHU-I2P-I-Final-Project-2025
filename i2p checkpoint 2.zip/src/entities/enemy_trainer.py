from __future__ import annotations
import pygame
from enum import Enum
from dataclasses import dataclass
from typing import override

from .entity import Entity
from src.sprites import Sprite
from src.core import GameManager
from src.core.services import input_manager, scene_manager
from src.utils import GameSettings, Direction, Position, PositionCamera
from src.utils.definition import Monster


class EnemyTrainerClassification(Enum):
    STATIONARY = "stationary"


@dataclass
class IdleMovement:
    def update(self, enemy: "EnemyTrainer", dt: float) -> None:
        return


class EnemyTrainer(Entity):
    classification: EnemyTrainerClassification
    max_tiles: int | None
    _movement: IdleMovement
    warning_sign: Sprite
    detected: bool
    los_direction: Direction

    @override
    def __init__(
        self,
        x: float,
        y: float,
        game_manager: GameManager,
        classification: EnemyTrainerClassification = EnemyTrainerClassification.STATIONARY,
        max_tiles: int | None = 2,
        facing: Direction | None = None,
        monsters: Monster | None = None,
    ) -> None:
        
        super().__init__(x, y, game_manager)
        self.classification = classification
        self.max_tiles = max_tiles
        self.monsters = monsters

        if classification == EnemyTrainerClassification.STATIONARY:
            self._movement = IdleMovement()
            if facing is None:
                raise ValueError("Idle EnemyTrainer requires a 'facing' Direction at instantiation")
            self._set_direction(facing)
        else:
            raise ValueError("Invalid classification")
        
        self.warning_sign = Sprite("exclamation.png", (GameSettings.TILE_SIZE // 2, GameSettings.TILE_SIZE // 2))
        self.warning_sign.update_pos(Position(x + GameSettings.TILE_SIZE // 4, y - GameSettings.TILE_SIZE // 2))
        self.detected = False

    @override
    def update(self, dt: float) -> None:
        self._movement.update(self, dt)
        self._has_los_to_player()
        
        # If THIS enemy detected the player and space is pressed, start battle with THIS enemy
        if self.detected and input_manager.key_pressed(pygame.K_SPACE):
            print(f"Battle initiated with enemy at position: ({self.position.x // GameSettings.TILE_SIZE}, {self.position.y // GameSettings.TILE_SIZE})")
            print(f"Enemy monsters: {self.monsters}")
            scene_manager.change_scene("battle", self)
        
        self.animation.update_pos(self.position)

    @override
    def draw(self, screen: pygame.Surface, camera: PositionCamera) -> None:
        super().draw(screen, camera)
        if self.detected:
            self.warning_sign.draw(screen, camera)
        if GameSettings.DRAW_HITBOXES:
            los_rect = self._get_los_rect()
            if los_rect is not None:
                pygame.draw.rect(screen, (255, 255, 0), camera.transform_rect(los_rect), 1)

    def _set_direction(self, direction: Direction) -> None:
        self.direction = direction
        if direction == Direction.RIGHT:
            self.animation.switch("right")
        elif direction == Direction.LEFT:
            self.animation.switch("left")
        elif direction == Direction.DOWN:
            self.animation.switch("down")
        else:
            self.animation.switch("up")
        self.los_direction = self.direction

    def _get_los_rect(self) -> pygame.Rect | None:
        tile = GameSettings.TILE_SIZE
        length = self.max_tiles * tile
        x = self.position.x
        y = self.position.y

        if self.direction == Direction.UP:
            return pygame.Rect(x, y - length, tile, length)
        if self.direction == Direction.DOWN:
            return pygame.Rect(x, y + tile, tile, length)
        if self.direction == Direction.RIGHT:
            return pygame.Rect(x + tile, y, length, tile)
        if self.direction == Direction.LEFT:
            return pygame.Rect(x - length, y, length, tile)
        return None

    def _has_los_to_player(self) -> bool:
        player = self.game_manager.player
        if player is None:
            self.detected = False
            return False
        los_rect = self._get_los_rect()
        if los_rect is None:
            self.detected = False
            return False
        player_rect = player.animation.rect
        self.detected = los_rect.colliderect(player_rect)
        return self.detected

    def _distance_to_player(self) -> float:
        player = self.game_manager.player
        if player is None:
            return float('inf')
        ex, ey = self.position.x, self.position.y
        px, py = player.position.x, player.position.y
        return ((px - ex) ** 2 + (py - ey) ** 2) ** 0.5
    
    @classmethod
    @override
    def from_dict(cls, data: dict, game_manager: GameManager) -> "EnemyTrainer":
        classification = EnemyTrainerClassification(data.get("classification", "stationary"))
        max_tiles = data.get("max_tiles")
        facing_val = data.get("facing")
        facing: Direction | None = None
        if facing_val is not None:
            if isinstance(facing_val, str):
                facing = Direction[facing_val]
            elif isinstance(facing_val, Direction):
                facing = facing_val
        if facing is None and classification == EnemyTrainerClassification.STATIONARY:
            facing = Direction.DOWN

        monsters: Monster | None = data.get("monsters")

        trainer = cls(
            data["x"] * GameSettings.TILE_SIZE,
            data["y"] * GameSettings.TILE_SIZE,
            game_manager,
            classification,
            max_tiles,
            facing,
            monsters
        )

        return trainer

    @override
    def to_dict(self) -> dict[str, object]:
        base: dict[str, object] = super().to_dict()
        base["classification"] = self.classification.value
        base["facing"] = self.direction.name
        base["max_tiles"] = self.max_tiles
        base["monsters"] = self.monsters
        return base