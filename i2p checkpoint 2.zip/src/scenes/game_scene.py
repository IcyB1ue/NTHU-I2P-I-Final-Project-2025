import pygame as pg
import threading
import time

from src.scenes.scene import Scene
from src.core import GameManager, OnlineManager
from src.utils import Logger, PositionCamera, GameSettings, Position
from src.core.services import sound_manager, input_manager, scene_manager
from src.sprites import Sprite, Text
from typing import override, Any
from src.interface.components.button import Button
from src.interface.components.toggle_button import ToggleButton
from src.interface.components.slider import Slider
from src.entities.enemy_trainer import EnemyTrainer

class GameScene(Scene):
    game_manager: GameManager
    online_manager: OnlineManager | None
    sprite_online: Sprite

    def __init__(self):
        super().__init__()
        # Game Manager
        manager = GameManager.load("saves/game0.json")
        if manager is None:
            Logger.error("Failed to load game manager")
            exit(1)
        self.game_manager = manager
        self.setting: Settings = Settings(self.game_manager)
        self.game_manager.bag.reload_bag()

        # Online Manager
        self.online_manager = OnlineManager() if GameSettings.IS_ONLINE else None
        self.sprite_online = Sprite("ingame_ui/options1.png", (GameSettings.TILE_SIZE, GameSettings.TILE_SIZE))

        # Player buttons
        px, py = GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT * 3 // 4
        self.bag_button = Button(
            "UI/button_backpack.png", "UI/button_backpack_hover.png",
            px + 500, py - 500, 75, 75,
            lambda: manager.bag.open()
        )
        self.settings_button = Button(
            "UI/button_setting.png", "UI/button_setting_hover.png",
            px + 500, py - 400, 75, 75,
            lambda: self.setting.open()
        )

    def get_closest_enemy(self) -> EnemyTrainer | None:
        closest = None
        min_dist = float('inf')
        for enemy in self.game_manager.current_enemy_trainers:
            dist = enemy._distance_to_player()
            # print(f"[DEBUG] Enemy at ({enemy.position.x // GameSettings.TILE_SIZE}, {enemy.position.y // GameSettings.TILE_SIZE}) distance: {dist // GameSettings.TILE_SIZE}")
            if dist < min_dist:
                min_dist = dist
                closest = enemy

        # if closest:
        #     print(f"[DEBUG] Selected closest enemy at ({closest.position.x // GameSettings.TILE_SIZE}, {closest.position.y // GameSettings.TILE_SIZE}) with distance {min_dist // GameSettings.TILE_SIZE}")
        # return closest

    @override
    def enter(self, data: Any = None) -> None:
        sound_manager.play_bgm("RBY 103 Pallet Town.ogg")
        if self.online_manager:
            self.online_manager.enter()

    @override
    def exit(self) -> None:
        if self.online_manager:
            self.online_manager.exit()

    @override
    def update(self, dt: float):
        self.game_manager.try_switch_map()

        # Update player
        if self.game_manager.player:
            self.game_manager.player.update(dt)

        # Update enemies
        for enemy in self.game_manager.current_enemy_trainers:
            enemy.update(dt)

        # Update UI
        if not self.game_manager.bag.overlay_show and not self.setting.overlay_show:
            self.bag_button.update(dt)
        if not self.setting.overlay_show:
            self.settings_button.update(dt)

        self.game_manager.bag.update(dt)
        self.setting.update(dt)

        # Online updates
        if self.game_manager.player and self.online_manager:
            _ = self.online_manager.update(
                self.game_manager.player.position.x,
                self.game_manager.player.position.y,
                self.game_manager.current_map.path_name
            )

        # Find closest enemy to player
        if self.game_manager.player:
            self.closest_enemy = self.get_closest_enemy()
            # if self.closest_enemy:
            #     print(f"[DEBUG] Closest enemy at ({self.closest_enemy.position.x // GameSettings.TILE_SIZE}, {self.closest_enemy.position.y // GameSettings.TILE_SIZE})")

    @override
    def draw(self, screen: pg.Surface):
        if self.game_manager.player:
            camera = self.game_manager.player.camera
            self.game_manager.current_map.draw(screen, camera)
            self.game_manager.player.draw(screen, camera)
        else:
            camera = PositionCamera(0, 0)
            self.game_manager.current_map.draw(screen, camera)

        for enemy in self.game_manager.current_enemy_trainers:
            enemy.draw(screen, camera)

        self.game_manager.bag.draw(screen)
        if not self.game_manager.bag.overlay_show and not self.setting.overlay_show:
            self.bag_button.draw(screen)
            self.settings_button.draw(screen)
        if self.setting.overlay_show:
            self.setting.draw(screen)

        if self.online_manager and self.game_manager.player:
            list_online = self.online_manager.get_list_players()
            for player in list_online:
                if player["map"] == self.game_manager.current_map.path_name:
                    pos = camera.transform_position_as_position(Position(player["x"], player["y"]))
                    self.sprite_online.update_pos(pos)
                    self.sprite_online.draw(screen)

# Settings class (unchanged except formatting)
class Settings:
    def __init__(self, game_manager: GameManager):
        self.game_manager = game_manager
        self.overlay_show = False
        self.overlay = Sprite("UI/raw/UI_Flat_Frame03a.png", (750, 625))
        self.overlay.rect.center = (GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT // 2)
        self.darken = pg.Surface((GameSettings.SCREEN_WIDTH, GameSettings.SCREEN_HEIGHT))
        self.darken.fill("Black")
        self.darken.set_alpha(128)
        self.darken_rect = self.darken.get_rect()
        px, py = GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT * 3 // 4
        self.back_button = Button(
            "UI/button_back.png", "UI/button_back_hover.png",
            px + 400, py - 500, 75, 75, lambda: self.close()
        )
        self.save_button = Button(
            "UI/button_save.png", "UI/button_save_hover.png",
            px + 150, py, 75, 75, lambda: self.game_manager.save("saves/game0.json")
        )
        self.load_button = Button(
            "UI/button_load.png", "UI/button_load_hover.png",
            px + 250, py, 75, 75, lambda: self._on_load()
        )
        self.mute_button = ToggleButton(
            "UI/raw/UI_Flat_ToggleOff03a.png", "UI/raw/UI_Flat_ToggleOn03a.png",
            px - 325, py - 300, 75, 75,
            lambda x: sound_manager.pause_all() if x else sound_manager.resume_all()
        )
        self.mute_text = Text("Mute Toggle", 30, "white")
        self.mute_text.rect.center = (525, 275)
        self.slider_audio = Slider(
            "UI/raw/UI_Flat_Bar06a.png",
            "UI/raw/UI_Flat_BarFill01e.png",
            "UI/raw/UI_Flat_Button02a_4.png",
            315, 175, 300, 50,
            initial_value=GameSettings.AUDIO_VOLUME,
            on_value_changed=lambda v: sound_manager.set_master_volume(v)
        )
        self.audio_text = Text("Audio Related", 50, "white")
        self.audio_text.rect.center = (475, 125)
    def _on_load(self):
        """Handle load button press - reload from save file"""
        if self.game_manager.reload_from_file("saves/game0.json"):
            Logger.info("Game loaded successfully!")
            # Reload the bag display to show updated HP values
            self.game_manager.bag.reload_bag()
        else:
            Logger.warning("Failed to load game")
    def open(self): self.overlay_show = True
    def close(self): self.overlay_show = False
    def update(self, dt: float):
        if self.overlay_show:
            self.back_button.update(dt)
            self.save_button.update(dt)
            self.load_button.update(dt)
            self.mute_button.update(dt)
            self.slider_audio.update(dt)
    def draw(self, screen: pg.Surface):
        if self.overlay_show:
            screen.blit(self.darken, self.darken_rect)
            self.overlay.draw(screen)
            self.back_button.draw(screen)
            self.save_button.draw(screen)
            self.load_button.draw(screen)
            self.mute_button.draw(screen)
            self.slider_audio.draw(screen)
            self.audio_text.draw(screen)
            self.mute_text.draw(screen)
