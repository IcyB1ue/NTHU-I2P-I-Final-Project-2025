import pygame as pg
from typing import override, Any
import random

from src.utils import GameSettings, Logger
from src.sprites import BackgroundSprite, Sprite
from src.scenes.scene import Scene
from src.interface.components import Button
from src.core.services import scene_manager, sound_manager
from src.sprites.sprite import Text
from src.entities.enemy_trainer import EnemyTrainer
from src.utils.definition import Monster

class HealthBar:
    """A visual health bar for battle monsters."""
    
    def __init__(self, x: int, y: int, width: int = 200, height: int = 20):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.current_hp = 100
        self.max_hp = 100
        
    def set_hp(self, current: int, maximum: int):
        """Set the current and max HP values."""
        self.current_hp = max(0, current)
        self.max_hp = max(1, maximum)
        
    def draw(self, screen: pg.Surface):
        """Draw the health bar."""
        # Background (black border)
        pg.draw.rect(screen, (0, 0, 0), (self.x - 2, self.y - 2, self.width + 4, self.height + 4))
        
        # Background (gray)
        pg.draw.rect(screen, (128, 128, 128), (self.x, self.y, self.width, self.height))
        
        # Calculate health percentage
        hp_percentage = self.current_hp / self.max_hp
        current_width = int(self.width * hp_percentage)
        
        # Health bar color based on HP percentage
        if hp_percentage > 0.5:
            color = (0, 255, 0)  # Green
        elif hp_percentage > 0.25:
            color = (255, 255, 0)  # Yellow
        else:
            color = (255, 0, 0)  # Red
            
        # Draw health bar
        if current_width > 0:
            pg.draw.rect(screen, color, (self.x, self.y, current_width, self.height))


class BattleScene(Scene):
    # Background Image
    background: BackgroundSprite
    # Buttons
    attack_button: Button
    run_button: Button
    switch_button: Button
    items_button: Button
    # Text
    attack_text: Text
    run_text: Text
    switch_text: Text
    items_text: Text
    battle_text: Text
    # Enemy data
    enemy_trainer: EnemyTrainer | None
    enemy_monster: Monster | None
    player_monster: Monster | None
    # Sprites
    enemy_monster_sprite: Sprite | None
    player_monster_sprite: Sprite | None
    game_announcement_banner_sprite: Sprite | None
    # Health bars
    enemy_health_bar: HealthBar
    player_health_bar: HealthBar
    # Monster info text
    enemy_name_text: Text | None
    enemy_level_text: Text | None
    player_name_text: Text | None
    player_level_text: Text | None
    enemy_hp_text: Text | None
    player_hp_text: Text | None
    # Battle state
    battle_message: str
    is_player_turn: bool
    battle_over: bool
    enemy_attack_timer: float
    run_away_timer: float
    message_delay_timer: float
    
    def __init__(self):
        super().__init__()
        # DON'T create a separate GameManager here!
        self.background = BackgroundSprite("backgrounds/background2.png")
        self.enemy_trainer = None
        self.enemy_monster = None
        self.player_monster = None
        self.enemy_monster_sprite = None
        self.player_monster_sprite = None
        self.is_player_turn = True
        self.battle_over = False
        self.battle_message = "What will you do?"
        self.enemy_attack_timer = 0
        self.run_away_timer = 0
        self.message_delay_timer = 0 

        # Create health bars
        self.enemy_health_bar = HealthBar(GameSettings.SCREEN_WIDTH * 3 // 4 - 100, 100)
        self.player_health_bar = HealthBar(GameSettings.SCREEN_WIDTH // 4 - 100, GameSettings.SCREEN_HEIGHT - 75)

        # Create the Banner
        self.game_announcement_banner_sprite = Sprite("UI/raw/UI_Flat_Banner04a.png", (400, 200))
        self.game_announcement_banner_sprite.rect.topleft = (20, 20)
        
        # Battle message text
        self.battle_text = Text(self.battle_message, 24, "black")
        self.battle_text.rect.topleft = (30, 30)

        px, py = GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT * 3 // 4
        
        self.attack_button = Button(
            "UI/raw/UI_Flat_Button02a_3.png", "UI/raw/UI_Flat_Button02a_2.png",
            px + 50, py - 50, 200, 100,
            self._on_attack
        )
        self.attack_text = Text("Attack", 30, "black")
        self.attack_text.rect.center = (px + 150, py)

        self.run_button = Button(
            "UI/raw/UI_Flat_Button02a_3.png", "UI/raw/UI_Flat_Button02a_2.png",
            px + 250, py - 50, 200, 100,
            self._on_run
        )
        self.run_text = Text("Run", 30, "black")
        self.run_text.rect.center = (px + 350, py)

        self.switch_button = Button(
            "UI/raw/UI_Flat_Button02a_3.png", "UI/raw/UI_Flat_Button02a_2.png",
            px + 50, py + 45, 200, 100,
            self._on_switch
        )
        self.switch_text = Text("Switch", 30, "black")
        self.switch_text.rect.center = (px + 150, py + 95)

        self.items_button = Button(
            "UI/raw/UI_Flat_Button02a_3.png", "UI/raw/UI_Flat_Button02a_2.png",
            px + 250, py + 45, 200, 100,
            self._on_items
        )
        self.items_text = Text("Items", 30, "black")
        self.items_text.rect.center = (px + 350, py + 95)

    def _calculate_damage(self, attacker: Monster, defender: Monster) -> int:
        """Calculate damage based on monster stats."""
        base_damage = attacker.get("attack", 10)
        defense = defender.get("defense", 5)
        level_modifier = attacker.get("level", 1) / 10
        random_factor = random.uniform(0.85, 1.0)
        damage = int((base_damage - defense * 0.5) * level_modifier * random_factor)
        return max(1, damage)

    def _player_attack(self):
        """Player attacks the enemy monster."""
        if not self.player_monster or not self.enemy_monster or self.battle_over:
            return
            
        damage = self._calculate_damage(self.player_monster, self.enemy_monster)
        self.enemy_monster["hp"] = max(0, self.enemy_monster["hp"] - damage)
        
        self.battle_message = f"{self.player_monster['name']} dealt {damage} damage!"
        self._update_battle_text()
        
        self.enemy_health_bar.set_hp(self.enemy_monster["hp"], self.enemy_monster["max_hp"])
        self._update_hp_text()
        
        if self.enemy_monster["hp"] <= 0:
            self.battle_message = f"Enemy {self.enemy_monster['name']} fainted! You win!"
            self._update_battle_text()
            self.battle_over = True
            return
            
        self.is_player_turn = False
        self.enemy_attack_timer = 1.5

    def _enemy_attack(self):
        """Enemy attacks the player monster."""
        if not self.player_monster or not self.enemy_monster or self.battle_over:
            return
            
        damage = self._calculate_damage(self.enemy_monster, self.player_monster)
        self.player_monster["hp"] = max(0, self.player_monster["hp"] - damage)
        
        self.battle_message = f"Enemy {self.enemy_monster['name']} dealt {damage} damage!"
        self._update_battle_text()
        
        self.player_health_bar.set_hp(self.player_monster["hp"], self.player_monster["max_hp"])
        self._update_hp_text()
        
        if self.player_monster["hp"] <= 0:
            self.battle_message = f"{self.player_monster['name']} fainted! You lost!"
            self._update_battle_text()
            self.battle_over = True
            return
            
        self.is_player_turn = True
        self.message_delay_timer = 1.5

    def _update_battle_text(self):
        """Update the battle message text."""
        self.battle_text = Text(self.battle_message, 20, "black")
        self.battle_text.rect.topleft = (50, 55)

    def _update_hp_text(self):
        """Update HP display text."""
        if self.enemy_monster:
            self.enemy_hp_text = Text(
                f"HP: {self.enemy_monster['hp']}/{self.enemy_monster['max_hp']}", 
                18, "black"
            )
            self.enemy_hp_text.rect.topleft = (GameSettings.SCREEN_WIDTH * 3 // 4 - 100, 75)
            
        if self.player_monster:
            self.player_hp_text = Text(
                f"HP: {self.player_monster['hp']}/{self.player_monster['max_hp']}", 
                18, "black"
            )
            self.player_hp_text.rect.topleft = (GameSettings.SCREEN_WIDTH // 4 - 100, GameSettings.SCREEN_HEIGHT - 100)

    def _on_attack(self):
        """Handle attack button press."""
        if self.is_player_turn and not self.battle_over:
            self._player_attack()
        elif self.battle_over:
            scene_manager.change_scene("game")

    def _on_run(self):
        """Handle run button press."""
        scene_manager.change_scene("game")
            
        # if self.is_player_turn:
        #     if random.random() > 0.5:
        #         self.battle_message = "Got away safely!"
        #         self._update_battle_text()
        #         self.run_away_timer = 1.5
        #     else:
        #         self.battle_message = "Can't escape!"
        #         self._update_battle_text()
        #         self.is_player_turn = False
        #         self.enemy_attack_timer = 1.5

    def _on_switch(self):
        """Handle switch button press."""
        if not self.battle_over:
            self.battle_message = "No other Pokemon available!"
            self._update_battle_text()

    def _on_items(self):
        """Handle items button press."""
        if not self.battle_over:
            self.battle_message = "No items available!"
            self._update_battle_text()

    def _load_monster_sprites(self):
        """Load the monster sprites based on the enemy trainer's monster data."""
        if not self.enemy_trainer or not self.enemy_trainer.monsters:
            Logger.warning("No enemy monster data to load sprites")
            return

        self.enemy_monster = self.enemy_trainer.monsters
        
        if isinstance(self.enemy_monster, dict):
            sprite_path = self.enemy_monster.get("sprite") or self.enemy_monster.get("sprite_path")
            if sprite_path:
                try:
                    self.enemy_monster_sprite = Sprite(
                        sprite_path, 
                        (GameSettings.TILE_SIZE * 3, GameSettings.TILE_SIZE * 3)
                    )
                    enemy_x = GameSettings.SCREEN_WIDTH * 3 // 4
                    enemy_y = GameSettings.SCREEN_HEIGHT // 4 + 50
                    self.enemy_monster_sprite.rect.center = (enemy_x, enemy_y)
                    
                    self.enemy_health_bar.set_hp(
                        self.enemy_monster.get("hp", 100),
                        self.enemy_monster.get("max_hp", 100)
                    )
                    
                    self.enemy_name_text = Text(self.enemy_monster.get("name", "Unknown"), 20, "black")
                    self.enemy_name_text.rect.topleft = (GameSettings.SCREEN_WIDTH * 3 // 4 - 100, 50)
                    
                    self.enemy_level_text = Text(f"Lv. {self.enemy_monster.get('level', 1)}", 18, "black")
                    self.enemy_level_text.rect.topright = (GameSettings.SCREEN_WIDTH * 3 // 4 + 100, 50)
                    
                    Logger.info(f"Loaded enemy monster sprite: {sprite_path}")
                except Exception as e:
                    Logger.error(f"Failed to load enemy monster sprite '{sprite_path}': {e}")
        
        # Load player's monster from enemy_trainer's game_manager
        if self.enemy_trainer and self.enemy_trainer.game_manager:
            self.player_monster = self.enemy_trainer.game_manager.bag.get_first_alive_monster()
            if self.player_monster:
                sprite_path = self.player_monster.get("sprite") or self.player_monster.get("sprite_path")
                if sprite_path:
                    try:
                        self.player_monster_sprite = Sprite(
                            sprite_path,
                            (GameSettings.TILE_SIZE * 3, GameSettings.TILE_SIZE * 3)
                        )
                        
                        self.player_monster_sprite.image = pg.transform.flip(
                            self.player_monster_sprite.image, 
                            True,
                            False
                        )
                        
                        player_x = GameSettings.SCREEN_WIDTH // 4
                        player_y = GameSettings.SCREEN_HEIGHT * 2 // 3
                        self.player_monster_sprite.rect.center = (player_x, player_y)
                        
                        self.player_health_bar.set_hp(
                            self.player_monster.get("hp", 100),
                            self.player_monster.get("max_hp", 100)
                        )
                        
                        self.player_name_text = Text(self.player_monster.get("name", "Unknown"), 20, "black")
                        self.player_name_text.rect.topleft = (GameSettings.SCREEN_WIDTH // 4 - 100, GameSettings.SCREEN_HEIGHT - 125)
                        
                        self.player_level_text = Text(f"Lv. {self.player_monster.get('level', 1)}", 18, "black")
                        self.player_level_text.rect.topright = (GameSettings.SCREEN_WIDTH // 4 + 100, GameSettings.SCREEN_HEIGHT - 125)
                        
                        Logger.info(f"Loaded player monster sprite: {sprite_path}")
                    except Exception as e:
                        Logger.error(f"Failed to load player monster sprite '{sprite_path}': {e}")
            else:
                Logger.warning("Player has no alive monsters!")
        
        self._update_hp_text()

    @override
    def enter(self, data: Any = None) -> None:
        """Called when entering the battle scene."""
        sound_manager.play_bgm("RBY 107 Battle! (Trainer).ogg")
        
        self.is_player_turn = True
        self.battle_over = False
        self.battle_message = "What will you do?"
        self.enemy_attack_timer = 0
        self.run_away_timer = 0
        self.message_delay_timer = 0
        self._update_battle_text()
        
        if isinstance(data, EnemyTrainer):
            self.enemy_trainer = data
            Logger.info(f"Battle started!")
            self._load_monster_sprites()
        else:
            Logger.warning("BattleScene entered without enemy trainer data!")
            self.enemy_trainer = None

    @override
    def exit(self) -> None:
        self.enemy_attack_timer = 0
        self.run_away_timer = 0
        self.message_delay_timer = 0
        self.enemy_monster_sprite = None
        self.player_monster_sprite = None
        self.enemy_monster = None
        self.player_monster = None

    @override
    def update(self, dt: float) -> None:
        if self.enemy_attack_timer > 0:
            self.enemy_attack_timer -= dt
            if self.enemy_attack_timer <= 0:
                self.enemy_attack_timer = 0
                self._enemy_attack()
        
        if self.message_delay_timer > 0:
            self.message_delay_timer -= dt
            if self.message_delay_timer <= 0:
                self.message_delay_timer = 0
                self.battle_message = "What will you do?"
                self._update_battle_text()
        
        if self.run_away_timer > 0:
            self.run_away_timer -= dt
            if self.run_away_timer <= 0:
                self.run_away_timer = 0
                if self.enemy_trainer and self.enemy_trainer.game_manager:
                    self.enemy_trainer.game_manager.save("saves/game0.json")
                    Logger.info("Game saved after escape")
                scene_manager.change_scene("game")
        
        if (self.is_player_turn and not self.battle_over) or self.battle_over:
            self.attack_button.update(dt)
            self.run_button.update(dt)
            self.switch_button.update(dt)
            self.items_button.update(dt)

    @override
    def draw(self, screen: pg.Surface) -> None:
        self.background.draw(screen)
        self.game_announcement_banner_sprite.draw(screen)
        
        if self.enemy_monster_sprite:
            self.enemy_monster_sprite.draw(screen)
        
        if self.player_monster_sprite:
            self.player_monster_sprite.draw(screen)
        
        self.enemy_health_bar.draw(screen)
        self.player_health_bar.draw(screen)
        
        if self.enemy_name_text:
            self.enemy_name_text.draw(screen)
        if self.enemy_level_text:
            self.enemy_level_text.draw(screen)
        if self.enemy_hp_text:
            self.enemy_hp_text.draw(screen)
            
        if self.player_name_text:
            self.player_name_text.draw(screen)
        if self.player_level_text:
            self.player_level_text.draw(screen)
        if self.player_hp_text:
            self.player_hp_text.draw(screen)
        
        self.battle_text.draw(screen)
        
        self.attack_button.draw(screen)
        self.run_button.draw(screen)
        self.switch_button.draw(screen)
        self.items_button.draw(screen)
        self.attack_text.draw(screen)
        self.run_text.draw(screen)
        self.switch_text.draw(screen)
        self.items_text.draw(screen)