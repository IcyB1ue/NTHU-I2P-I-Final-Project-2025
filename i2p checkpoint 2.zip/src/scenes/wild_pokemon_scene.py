import pygame as pg
from typing import override, Any
import random

from src.utils import GameSettings, Logger
from src.sprites import BackgroundSprite, Sprite
from src.scenes.scene import Scene
from src.interface.components import Button
from src.core.services import scene_manager, sound_manager
from src.sprites.sprite import Text
from src.utils.definition import Monster

class HealthBar:
    """A visual health bar for battle monsters."""
    
    def __init__(self, x: int, y: int, width: int = 200, height: int = 20):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.current_hp = 100
        self.max_hp = 100
        
    def set_hp(self, current: int, maximum: int):
        """Set the current and max HP values."""
        self.current_hp = max(0, current)
        self.max_hp = max(1, maximum)
        
    def draw(self, screen: pg.Surface):
        """Draw the health bar."""
        pg.draw.rect(screen, (0, 0, 0), (self.x - 2, self.y - 2, self.width + 4, self.height + 4))
        pg.draw.rect(screen, (128, 128, 128), (self.x, self.y, self.width, self.height))
        
        hp_percentage = self.current_hp / self.max_hp
        current_width = int(self.width * hp_percentage)
        
        if hp_percentage > 0.5:
            color = (0, 255, 0)
        elif hp_percentage > 0.25:
            color = (255, 255, 0)
        else:
            color = (255, 0, 0)
            
        if current_width > 0:
            pg.draw.rect(screen, color, (self.x, self.y, current_width, self.height))


class WildPokemonScene(Scene):
    """Scene for encountering and catching wild Pokemon."""
    
    background: BackgroundSprite
    attack_button: Button
    catch_button: Button
    run_button: Button
    attack_text: Text
    catch_text: Text
    run_text: Text
    battle_text: Text
    
    wild_pokemon: Monster | None
    player_monster: Monster | None
    
    wild_pokemon_sprite: Sprite | None
    player_monster_sprite: Sprite | None
    game_announcement_banner_sprite: Sprite | None
    
    wild_health_bar: HealthBar
    player_health_bar: HealthBar
    
    wild_name_text: Text | None
    wild_level_text: Text | None
    player_name_text: Text | None
    player_level_text: Text | None
    wild_hp_text: Text | None
    player_hp_text: Text | None
    
    battle_message: str
    is_player_turn: bool
    battle_over: bool
    pokemon_caught: bool
    wild_attack_timer: float
    escape_timer: float
    message_delay_timer: float
    victory_timer: float  # Timer for when Pokemon is caught or fainted
    
    # Reference to game manager (passed from GameScene)
    game_manager: Any
    
    def __init__(self):
        super().__init__()
        self.background = BackgroundSprite("backgrounds/background2.png")
        self.wild_pokemon = None
        self.player_monster = None
        self.wild_pokemon_sprite = None
        self.player_monster_sprite = None
        self.game_manager = None
        
        self.is_player_turn = True
        self.battle_over = False
        self.pokemon_caught = False
        self.battle_message = "A wild Pokemon appeared!"
        self.wild_attack_timer = 0
        self.escape_timer = 0
        self.message_delay_timer = 0
        self.victory_timer = 0  # Timer for victory/catch delay

        # Health bars
        self.wild_health_bar = HealthBar(GameSettings.SCREEN_WIDTH * 3 // 4 - 100, 100)
        self.player_health_bar = HealthBar(GameSettings.SCREEN_WIDTH // 4 - 100, GameSettings.SCREEN_HEIGHT - 75)

        # Banner
        self.game_announcement_banner_sprite = Sprite("UI/raw/UI_Flat_Banner04a.png", (400, 200))
        self.game_announcement_banner_sprite.rect.topleft = (20, 20)
        
        self.battle_text = Text(self.battle_message, 24, "black")
        self.battle_text.rect.topleft = (30, 30)

        px, py = GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT * 3 // 4
        
        # Attack button
        self.attack_button = Button(
            "UI/raw/UI_Flat_Button02a_3.png", "UI/raw/UI_Flat_Button02a_2.png",
            px + 50, py - 50, 200, 100,
            self._on_attack
        )
        self.attack_text = Text("Attack", 30, "black")
        self.attack_text.rect.center = (px + 150, py)

        # Catch button (replaces Switch)
        self.catch_button = Button(
            "UI/raw/UI_Flat_Button02a_3.png", "UI/raw/UI_Flat_Button02a_2.png",
            px + 250, py - 50, 200, 100,
            self._on_catch
        )
        self.catch_text = Text("Catch", 30, "black")
        self.catch_text.rect.center = (px + 350, py)

        # Run button
        self.run_button = Button(
            "UI/raw/UI_Flat_Button02a_3.png", "UI/raw/UI_Flat_Button02a_2.png",
            px + 150, py + 45, 200, 100,
            self._on_run
        )
        self.run_text = Text("Run", 30, "black")
        self.run_text.rect.center = (px + 250, py + 95)

    def _generate_wild_pokemon(self) -> Monster:
        """Generate a random wild Pokemon."""
        # Pool of possible wild Pokemon
        wild_pool = [
            {"name": "Pikachu", "max_hp": 40, "level": random.randint(2, 5), "sprite_path": "menu_sprites/menusprite1.png", "attack": 8, "defense": 25},
            {"name": "Charizard", "max_hp": 35, "level": random.randint(2, 5), "sprite_path": "menu_sprites/menusprite2.png", "attack": 7, "defense": 24},
            {"name": "Blastoise", "max_hp": 30, "level": random.randint(2, 4), "sprite_path": "menu_sprites/menusprite3.png", "attack": 5, "defense": 26},
            {"name": "Venusaur", "max_hp": 32, "level": random.randint(2, 4), "sprite_path": "menu_sprites/menusprite4.png", "attack": 6, "defense": 25},
            {"name": "Gengar", "max_hp": 38, "level": random.randint(3, 6), "sprite_path": "menu_sprites/menusprite5.png", "attack": 9, "defense": 24},
            {"name": "Dragonite", "max_hp": 42, "level": random.randint(3, 6), "sprite_path": "menu_sprites/menusprite6.png", "attack": 10, "defense": 23}
        ]
        
        pokemon = random.choice(wild_pool).copy()
        pokemon["hp"] = pokemon["max_hp"]
        return pokemon

    def _calculate_damage(self, attacker: Monster, defender: Monster) -> int:
        """Calculate damage based on monster stats."""
        base_damage = attacker.get("attack", 10)
        defense = defender.get("defense", 5)
        level_modifier = attacker.get("level", 1) / 10
        random_factor = random.uniform(0.85, 1.0)
        damage = int((base_damage - defense * 0.5) * level_modifier * random_factor)
        return max(1, damage)

    def _calculate_catch_chance(self) -> float:
        """Calculate catch chance based on wild Pokemon's hp ayyayayayayyaya"""
        if not self.wild_pokemon:
            return 0.0
        
        hp_percentage = self.wild_pokemon["hp"] / self.wild_pokemon["max_hp"]
        
        # Base catch rate: 30% at full HP, up to 90% at very low HP
        base_rate = 0.3
        hp_bonus = (1 - hp_percentage) * 0.6
        
        return min(base_rate + hp_bonus, 0.95)

    def _player_attack(self):
        """Player attacks the wild Pokemon."""
        if not self.player_monster or not self.wild_pokemon or self.battle_over:
            return
            
        damage = self._calculate_damage(self.player_monster, self.wild_pokemon)
        self.wild_pokemon["hp"] = max(0, self.wild_pokemon["hp"] - damage)
        
        self.battle_message = f"{self.player_monster['name']} dealt {damage} damage!"
        self._update_battle_text()
        
        self.wild_health_bar.set_hp(self.wild_pokemon["hp"], self.wild_pokemon["max_hp"])
        self._update_hp_text()
        
        if self.wild_pokemon["hp"] <= 0:
            self.battle_message = f"Wild {self.wild_pokemon['name']} fainted!"
            self._update_battle_text()
            self.battle_over = True
            self.victory_timer = 1.5  # Wait 1.5 seconds before returning
            return
            
        self.is_player_turn = False
        self.wild_attack_timer = 1.5

    def _wild_attack(self):
        """Wild Pokemon attacks the player."""
        if not self.player_monster or not self.wild_pokemon or self.battle_over:
            return
            
        damage = self._calculate_damage(self.wild_pokemon, self.player_monster)
        self.player_monster["hp"] = max(0, self.player_monster["hp"] - damage)
        
        self.battle_message = f"Wild {self.wild_pokemon['name']} dealt {damage} damage!"
        self._update_battle_text()
        
        self.player_health_bar.set_hp(self.player_monster["hp"], self.player_monster["max_hp"])
        self._update_hp_text()
        
        if self.player_monster["hp"] <= 0:
            self.battle_message = f"{self.player_monster['name']} fainted!"
            self._update_battle_text()
            self.battle_over = True
            return
            
        self.is_player_turn = True
        self.message_delay_timer = 1.5

    def _attempt_catch(self):
        """Attempt to catch the wild Pokemon."""
        if not self.wild_pokemon or self.battle_over:
            return
        
        # Check if player has Pokeballs
        pokeball_item = None
        for item in self.game_manager.bag._items_data:
            if item["name"].lower() == "pokeball":
                pokeball_item = item
                break
        
        if not pokeball_item or pokeball_item["count"] <= 0:
            self.battle_message = "No Pokeballs left!"
            self._update_battle_text()
            return
        
        # Use a Pokeball
        pokeball_item["count"] -= 1
        
        # Calculate catch chance
        catch_chance = self._calculate_catch_chance()
        roll = random.random()
        
        Logger.info(f"Catch attempt: {catch_chance:.2%} chance, rolled {roll:.2f}")
        
        if roll < catch_chance:
            # Success!
            self.battle_message = f"Gotcha! {self.wild_pokemon['name']} was caught!"
            self._update_battle_text()
            
            # Add to bag
            caught_pokemon = self.wild_pokemon.copy()
            self.game_manager.bag._monsters_data.append(caught_pokemon)
            
            self.pokemon_caught = True
            self.battle_over = True
            self.victory_timer = 1.5  # Wait 1.5 seconds before returning
            Logger.info(f"Caught {caught_pokemon['name']}!")
        else:
            # Failed
            self.battle_message = f"{self.wild_pokemon['name']} broke free!"
            self._update_battle_text()
            
            # Wild Pokemon gets a free turn
            self.is_player_turn = False
            self.wild_attack_timer = 1.5

    def _on_attack(self):
        """Handle attack button press."""
        if self.is_player_turn and not self.battle_over:
            self._player_attack()
        # Removed the elif - buttons don't work when battle is over, wait for timer

    def _on_catch(self):
        """Handle catch button press."""
        if self.is_player_turn and not self.battle_over:
            self._attempt_catch()
        # Removed the elif - buttons don't work when battle is over, wait for timer

    def _on_run(self):
        """Handle run button press."""
        # Can't run if battle is over
        if self.battle_over:
            return
            
        if self.is_player_turn:
            # 75% chance to escape from wild Pokemon
            if random.random() < 0.75:
                self.battle_message = "Got away safely!"
                self._update_battle_text()
                self.escape_timer = 1.5
            else:
                self.battle_message = "Can't escape!"
                self._update_battle_text()
                self.is_player_turn = False
                self.wild_attack_timer = 1.5

    def _update_battle_text(self):
        """Update the battle message text."""
        self.battle_text = Text(self.battle_message, 20, "black")
        self.battle_text.rect.topleft = (50, 55)

    def _update_hp_text(self):
        """Update HP display text."""
        if self.wild_pokemon:
            self.wild_hp_text = Text(
                f"HP: {self.wild_pokemon['hp']}/{self.wild_pokemon['max_hp']}", 
                18, "black"
            )
            self.wild_hp_text.rect.topleft = (GameSettings.SCREEN_WIDTH * 3 // 4 - 100, 75)
            
        if self.player_monster:
            self.player_hp_text = Text(
                f"HP: {self.player_monster['hp']}/{self.player_monster['max_hp']}", 
                18, "black"
            )
            self.player_hp_text.rect.topleft = (GameSettings.SCREEN_WIDTH // 4 - 100, GameSettings.SCREEN_HEIGHT - 100)

    def _load_sprites(self):
        """Load Pokemon sprites."""
        if not self.wild_pokemon:
            return
        
        # Load wild Pokemon sprite
        sprite_path = self.wild_pokemon.get("sprite") or self.wild_pokemon.get("sprite_path")
        if sprite_path:
            try:
                self.wild_pokemon_sprite = Sprite(
                    sprite_path, 
                    (GameSettings.TILE_SIZE * 3, GameSettings.TILE_SIZE * 3)
                )
                wild_x = GameSettings.SCREEN_WIDTH * 3 // 4
                wild_y = GameSettings.SCREEN_HEIGHT // 4 + 50
                self.wild_pokemon_sprite.rect.center = (wild_x, wild_y)
                
                self.wild_health_bar.set_hp(
                    self.wild_pokemon["hp"],
                    self.wild_pokemon["max_hp"]
                )
                
                self.wild_name_text = Text(self.wild_pokemon["name"], 20, "black")
                self.wild_name_text.rect.topleft = (GameSettings.SCREEN_WIDTH * 3 // 4 - 100, 50)
                
                self.wild_level_text = Text(f"Lv. {self.wild_pokemon['level']}", 18, "black")
                self.wild_level_text.rect.topright = (GameSettings.SCREEN_WIDTH * 3 // 4 + 100, 50)
                
            except Exception as e:
                Logger.error(f"Failed to load wild Pokemon sprite: {e}")
        
        # Load player's Pokemon
        if self.game_manager:
            self.player_monster = self.game_manager.bag.get_first_alive_monster()
            if self.player_monster:
                sprite_path = self.player_monster.get("sprite") or self.player_monster.get("sprite_path")
                if sprite_path:
                    try:
                        self.player_monster_sprite = Sprite(
                            sprite_path,
                            (GameSettings.TILE_SIZE * 3, GameSettings.TILE_SIZE * 3)
                        )
                        
                        self.player_monster_sprite.image = pg.transform.flip(
                            self.player_monster_sprite.image, 
                            True,
                            False
                        )
                        
                        player_x = GameSettings.SCREEN_WIDTH // 4
                        player_y = GameSettings.SCREEN_HEIGHT * 2 // 3
                        self.player_monster_sprite.rect.center = (player_x, player_y)
                        
                        self.player_health_bar.set_hp(
                            self.player_monster["hp"],
                            self.player_monster["max_hp"]
                        )
                        
                        self.player_name_text = Text(self.player_monster["name"], 20, "black")
                        self.player_name_text.rect.topleft = (GameSettings.SCREEN_WIDTH // 4 - 100, GameSettings.SCREEN_HEIGHT - 125)
                        
                        self.player_level_text = Text(f"Lv. {self.player_monster['level']}", 18, "black")
                        self.player_level_text.rect.topright = (GameSettings.SCREEN_WIDTH // 4 + 100, GameSettings.SCREEN_HEIGHT - 125)
                        
                    except Exception as e:
                        Logger.error(f"Failed to load player Pokemon sprite: {e}")
        
        self._update_hp_text()

    @override
    def enter(self, data: Any = None) -> None:
        """Called when entering the wild Pokemon scene."""
        sound_manager.play_bgm("RBY 107 Battle! (Trainer).ogg")
        
        # data should be the game_manager
        self.game_manager = data
        
        # Generate wild Pokemon
        self.wild_pokemon = self._generate_wild_pokemon()
        
        # Reset state
        self.is_player_turn = True
        self.battle_over = False
        self.pokemon_caught = False
        self.battle_message = f"A wild {self.wild_pokemon['name']} appeared!"
        self.wild_attack_timer = 0
        self.escape_timer = 0
        self.message_delay_timer = 0
        self.victory_timer = 0
        self._update_battle_text()
        
        self._load_sprites()

    @override
    def exit(self) -> None:
        self.wild_attack_timer = 0
        self.escape_timer = 0
        self.message_delay_timer = 0
        self.victory_timer = 0
        self.wild_pokemon_sprite = None
        self.player_monster_sprite = None
        self.wild_pokemon = None
        self.player_monster = None

    @override
    def update(self, dt: float) -> None:
        # Handle victory timer (when Pokemon is caught or fainted)
        if self.victory_timer > 0:
            self.victory_timer -= dt
            if self.victory_timer <= 0:
                self.victory_timer = 0
                scene_manager.change_scene("game")
                return
        
        if self.wild_attack_timer > 0:
            self.wild_attack_timer -= dt
            if self.wild_attack_timer <= 0:
                self.wild_attack_timer = 0
                self._wild_attack()
        
        if self.message_delay_timer > 0:
            self.message_delay_timer -= dt
            if self.message_delay_timer <= 0:
                self.message_delay_timer = 0
                self.battle_message = "What will you do?"
                self._update_battle_text()
        
        if self.escape_timer > 0:
            self.escape_timer -= dt
            if self.escape_timer <= 0:
                self.escape_timer = 0
                scene_manager.change_scene("game")
        
        # Only update buttons if not in victory state and it's player's turn
        if self.victory_timer <= 0 and ((self.is_player_turn and not self.battle_over) or self.battle_over):
            self.attack_button.update(dt)
            self.catch_button.update(dt)
            self.run_button.update(dt)

    @override
    def draw(self, screen: pg.Surface) -> None:
        self.background.draw(screen)
        self.game_announcement_banner_sprite.draw(screen)
        
        if self.wild_pokemon_sprite:
            self.wild_pokemon_sprite.draw(screen)
        
        if self.player_monster_sprite:
            self.player_monster_sprite.draw(screen)
        
        self.wild_health_bar.draw(screen)
        self.player_health_bar.draw(screen)
        
        if self.wild_name_text:
            self.wild_name_text.draw(screen)
        if self.wild_level_text:
            self.wild_level_text.draw(screen)
        if self.wild_hp_text:
            self.wild_hp_text.draw(screen)
            
        if self.player_name_text:
            self.player_name_text.draw(screen)
        if self.player_level_text:
            self.player_level_text.draw(screen)
        if self.player_hp_text:
            self.player_hp_text.draw(screen)
        
        self.battle_text.draw(screen)
        
        self.attack_button.draw(screen)
        self.catch_button.draw(screen)
        self.run_button.draw(screen)
        self.attack_text.draw(screen)
        self.catch_text.draw(screen)
        self.run_text.draw(screen)