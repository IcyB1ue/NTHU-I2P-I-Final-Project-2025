import pygame as pg
import json
from src.utils import GameSettings, Logger
from src.utils.definition import Monster, Item
from src.sprites import Sprite, Text
from src.interface.components.button import Button
from src.core.services import input_manager


class Bag:
    _monsters_data: list[Monster]
    _items_data: list[Item]

    def __init__(self, monsters_data: list[Monster] | None = None, items_data: list[Item] | None = None):
        self._monsters_data = monsters_data if monsters_data else []
        self._items_data = items_data if items_data else []

        self.overlay = Sprite("UI/raw/UI_Flat_Frame02a.png", (750, 625))
        self.overlay.rect.center = (GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT // 2)
        self.boxes = [Sprite("UI/raw/UI_Flat_Bar07a.png", (275, 100)) for _ in range(6)]

        # Visual elements
        self.monsters_sprite = []
        self.monsters_data = []  # Text elements
        self.item_sprite = []
        self.item_data = []      # Text elements

        px, py = GameSettings.SCREEN_WIDTH // 2, GameSettings.SCREEN_HEIGHT * 3 // 4
        self.back_button = Button(
            "UI/button_back.png", "UI/button_back_hover.png",
            px + 400, py - 500, 75, 75,
            lambda: self.close()
        )

        self.darken = pg.Surface((GameSettings.SCREEN_WIDTH, GameSettings.SCREEN_HEIGHT))
        self.darken.fill("Black")
        self.darken.set_alpha(128)
        self.darken_rect = self.darken.get_rect()

        self.overlay_show = False
        self.boxes_show = False

    # ---------------------------
    # Monster utilities
    # ---------------------------
    def get_first_alive_monster(self) -> Monster | None:
        for monster in self._monsters_data:
            if monster["hp"] > 0:
                return monster
        return None

    def get_all_alive_monsters(self) -> list[Monster]:
        return [monster for monster in self._monsters_data if monster["hp"] > 0]

    def get_monster_count(self) -> int:
        return len(self._monsters_data)

    def get_alive_monster_count(self) -> int:
        return len(self.get_all_alive_monsters())

    # ---------------------------
    # Open / close
    # ---------------------------
    def open(self, reload_from_memory: bool = True, reload_from_disk: bool = False):
        """
        Opens the Bag overlay and optionally reloads the latest state.
        """
        input_manager.reset()

        if reload_from_disk:
            self._reload_from_disk()

        if reload_from_memory or reload_from_disk:
            self.reload_bag()

        self.overlay_show = True
        self.boxes_show = True

    def close(self):
        input_manager.reset()
        self.overlay_show = False
        self.boxes_show = False

    # ---------------------------
    # Update / draw
    # ---------------------------
    def update(self, dt: float):
        if self.overlay_show:
            self.back_button.update(dt)
        if self.boxes_show:
            for box in self.boxes:
                box.update(dt)
            for monster in self.monsters_sprite:
                monster.update(dt)
            for item in self.item_sprite:
                item.update(dt)

    def draw(self, screen: pg.Surface):
        if self.overlay_show:
            screen.blit(self.darken, self.darken_rect)
            self.overlay.draw(screen)
            self.back_button.draw(screen)

            for box in self.boxes:
                box.draw(screen)
            for monster in self.monsters_sprite:
                monster.draw(screen)
            for data in self.monsters_data:
                data.draw(screen)

            for item in self.item_sprite:
                item.draw(screen)
            for item_data in self.item_data:
                item_data.draw(screen)

    # ---------------------------
    # Serialization
    # ---------------------------
    def to_dict(self) -> dict[str, object]:
        return {
            "monsters": [dict(m) for m in self._monsters_data],
            "items": [dict(i) for i in self._items_data]
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> "Bag":
        monsters_raw = data.get("monsters") or []
        monsters: list[Monster] = [dict(m) for m in monsters_raw]  # always dicts

        items_raw = data.get("items") or []
        items: list[Item] = [dict(i) for i in items_raw]  # always dicts

        bag = cls(monsters, items)
        bag.reload_bag()
        return bag

    # ---------------------------
    # Visual helpers
    # ---------------------------
    def _clear_visuals(self):
        self.monsters_sprite = []
        self.monsters_data = []
        self.item_sprite = []
        self.item_data = []

    def reload_bag(self):
        """Rebuild visual elements using live Monster dicts."""
        self._clear_visuals()

        ind = 0
        offset = 0
        for i, box in enumerate(self.boxes):
            if i >= len(self._monsters_data):
                break

            box.rect.center = (425, 110 + 100 * i)
            current_monster = self._monsters_data[i]

            sprite_to_append = Sprite(current_monster["sprite_path"], (60, 60))
            sprite_to_append.rect.center = (450, 110 + 100 * i)
            self.monsters_sprite.append(sprite_to_append)

            name_text = Text(current_monster["name"], 20, "white")
            name_text.rect.center = (350, 90 + 23 * ind + 31 * offset)
            self.monsters_data.append(name_text)
            ind += 1

            hp_text = Text(f"{current_monster['hp']}/{current_monster['max_hp']}", 20, "white")
            hp_text.rect.center = (350, 90 + 23 * ind + 31 * offset)
            self.monsters_data.append(hp_text)
            ind += 1

            level_text = Text(f"Lv. {current_monster['level']}", 20, "white")
            level_text.rect.center = (350, 90 + 23 * ind + 31 * offset)
            self.monsters_data.append(level_text)
            ind += 1
            offset += 1

        ind_item = 0
        offset_item = 0
        for i, item in enumerate(self._items_data):
            sprite_to_append = Sprite(item["sprite_path"], (60, 60))
            sprite_to_append.rect.center = (750, 110 + 100 * i)
            self.item_sprite.append(sprite_to_append)

            name_text = Text(item["name"], 30, "white")
            name_text.rect.center = (900, 98 + 29 * ind_item + 43 * offset_item)
            self.item_data.append(name_text)
            ind_item += 1

            count_text = Text(str(item["count"]), 30, "white")
            count_text.rect.center = (900, 98 + 29 * ind_item + 43 * offset_item)
            self.item_data.append(count_text)
            ind_item += 1
            offset_item += 1

        self.overlay_show = False
        self.boxes_show = False

    # ---------------------------
    # Disk reload
    # ---------------------------
    def _reload_from_disk(self):
        """Reload Bag data from 'game0.json'."""
        try:
            with open("game0.json", "r") as f:
                data = json.load(f)
            bag_data = data.get("bag", {})
            self._monsters_data = [dict(m) for m in bag_data.get("monsters", [])]
            self._items_data = [dict(i) for i in bag_data.get("items", [])]
        except Exception as e:
            Logger.warning(f"Failed to reload Bag from disk: {e}")
